"""
Analysis pipeline handler for RTL auto-analysis.

Invoked by Step Functions with a ``stage`` parameter to dispatch
the appropriate analysis function. Each stage reads from OpenSearch/S3,
runs analysis logic, writes results back, and updates DynamoDB status.

Requirements validated: 1.2, 1.3, 1.4, 2.1–2.5, 3.1–3.5, 4.1–4.5, 5.1–5.5, 11.7
"""

import json
import logging
import os
from datetime import datetime, timezone
from typing import Any

import boto3

from hierarchy import build_hierarchy, serialize_hierarchy_json, serialize_hierarchy_csv
from clock_domain import extract_clock_domains, classify_clock_domain, detect_cdc_boundary
from dataflow import build_dataflow_connections
from topic_classifier import classify_topic, suggest_inherited_topic
from claim_generator import generate_claims
from hdd_generator import generate_hdd_section
from variant_delta import extract_variant_delta
from package_extractor import extract_package_params, identify_chip_config, extract_enum_mapping
from edc_analyzer import (
    build_edc_topology, identify_harvest_bypass,
    extract_serial_bus_interface, build_node_id_table,
)
from noc_analyzer import (
    extract_routing_algorithms, extract_flit_structure,
    extract_struct_fields, extract_axi_address_gasket, identify_security_fence,
)
from overlay_analyzer import (
    extract_cpu_cluster_params, identify_submodule_roles,
    extract_l1_cache_params, extract_apb_slaves,
)
from sram_inventory import build_sram_inventory

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# ---------------------------------------------------------------------------
# 환경 변수
# ---------------------------------------------------------------------------
RTL_S3_BUCKET = os.environ.get("RTL_S3_BUCKET", "")
OPENSEARCH_ENDPOINT = os.environ.get("RTL_OPENSEARCH_ENDPOINT", "")
OPENSEARCH_INDEX = os.environ.get("RTL_OPENSEARCH_INDEX", "rtl-knowledge-base-index")
BEDROCK_REGION = os.environ.get("BEDROCK_REGION", "us-east-1")
DYNAMODB_EXTRACTION_TABLE = os.environ.get("DYNAMODB_EXTRACTION_TABLE", "rag-extraction-tasks")

s3_client = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")

BATCH_SIZE = 100


# ---------------------------------------------------------------------------
# 공통 유틸리티
# ---------------------------------------------------------------------------

def _get_opensearch_auth():
    """OpenSearch AOSS SigV4 인증 객체 생성."""
    import requests
    from requests_aws4auth import AWS4Auth

    session = boto3.Session()
    credentials = session.get_credentials()
    aoss_region = BEDROCK_REGION
    auth = AWS4Auth(
        credentials.access_key,
        credentials.secret_key,
        aoss_region,
        "aoss",
        session_token=credentials.token,
    )
    return auth


def _opensearch_scroll_query(
    pipeline_id: str, analysis_type: str, max_docs: int = 10000,
) -> list[dict]:
    """OpenSearch에서 pipeline_id + analysis_type으로 문서를 페이지네이션 조회.

    AOSS는 scroll API를 지원하지 않으므로 search_after 방식으로 페이지네이션한다.
    _id 기준 정렬 후 마지막 _id를 search_after로 전달하여 다음 페이지를 조회한다.
    """
    import requests

    if not OPENSEARCH_ENDPOINT:
        logger.warning("OPENSEARCH_ENDPOINT not set, returning empty results")
        return []

    auth = _get_opensearch_auth()
    url = f"{OPENSEARCH_ENDPOINT}/{OPENSEARCH_INDEX}/_search"
    results: list[dict] = []
    search_after: list[str] | None = None

    while len(results) < max_docs:
        search_body: dict[str, Any] = {
            "size": BATCH_SIZE,
            "sort": [{"_id": "asc"}],
            "query": {
                "bool": {
                    "must": [
                        {"term": {"pipeline_id": pipeline_id}},
                        {"term": {"analysis_type": analysis_type}},
                    ],
                },
            },
        }
        if search_after is not None:
            search_body["search_after"] = search_after

        try:
            resp = requests.post(
                url, auth=auth, json=search_body,
                headers={"Content-Type": "application/json"}, timeout=60,
            )
            resp.raise_for_status()
            data = resp.json()
            hits = data.get("hits", {}).get("hits", [])

            if not hits:
                break

            for hit in hits:
                doc = hit.get("_source", {})
                doc["_id"] = hit.get("_id", "")
                results.append(doc)

            # search_after: 마지막 hit의 sort 값
            search_after = hits[-1].get("sort")
            if not search_after:
                break

            logger.info(json.dumps({
                "event": "scroll_page",
                "pipeline_id": pipeline_id,
                "analysis_type": analysis_type,
                "page_size": len(hits),
                "total_so_far": len(results),
            }))

            # 배치 크기보다 적으면 마지막 페이지
            if len(hits) < BATCH_SIZE:
                break

        except Exception as e:
            logger.error(json.dumps({
                "event": "opensearch_scroll_error",
                "pipeline_id": pipeline_id,
                "error": str(e),
            }))
            break

    return results


def _index_document(doc: dict[str, Any]) -> bool:
    """단일 문서를 OpenSearch에 인덱싱."""
    import requests

    if not OPENSEARCH_ENDPOINT:
        return False

    auth = _get_opensearch_auth()
    url = f"{OPENSEARCH_ENDPOINT}/{OPENSEARCH_INDEX}/_doc"
    try:
        resp = requests.post(
            url, auth=auth, json=doc,
            headers={"Content-Type": "application/json"}, timeout=30,
        )
        resp.raise_for_status()
        return True
    except Exception as e:
        logger.error(json.dumps({
            "event": "opensearch_index_error",
            "error": str(e),
        }))
        return False


def _bulk_index_documents(docs: list[dict[str, Any]]) -> int:
    """여러 문서를 OpenSearch _bulk API로 일괄 인덱싱.

    AOSS는 _bulk API를 지원한다. NDJSON 형식으로 전송.
    Returns: 성공적으로 인덱싱된 문서 수.
    """
    import requests

    if not OPENSEARCH_ENDPOINT or not docs:
        return 0

    auth = _get_opensearch_auth()
    url = f"{OPENSEARCH_ENDPOINT}/{OPENSEARCH_INDEX}/_bulk"

    # NDJSON 형식: {"index": {}}\n{doc}\n{"index": {}}\n{doc}\n...
    lines: list[str] = []
    for doc in docs:
        lines.append(json.dumps({"index": {}}))
        lines.append(json.dumps(doc, ensure_ascii=False, default=str))
    body = "\n".join(lines) + "\n"

    try:
        resp = requests.post(
            url, auth=auth, data=body.encode("utf-8"),
            headers={"Content-Type": "application/x-ndjson"}, timeout=60,
        )
        resp.raise_for_status()
        result = resp.json()
        errors = result.get("errors", False)
        items = result.get("items", [])
        success_count = sum(
            1 for item in items
            if item.get("index", {}).get("status", 0) in (200, 201)
        )
        if errors:
            failed = len(items) - success_count
            logger.warning(json.dumps({
                "event": "bulk_index_partial_error",
                "total": len(docs),
                "success": success_count,
                "failed": failed,
            }))
        return success_count
    except Exception as e:
        logger.error(json.dumps({
            "event": "bulk_index_error",
            "doc_count": len(docs),
            "error": str(e),
        }))
        return 0


def _update_document(doc_id: str, update_fields: dict[str, Any]) -> bool:
    """OpenSearch 문서의 특정 필드를 업데이트."""
    import requests

    if not OPENSEARCH_ENDPOINT:
        return False

    auth = _get_opensearch_auth()
    url = f"{OPENSEARCH_ENDPOINT}/{OPENSEARCH_INDEX}/_doc/{doc_id}"
    try:
        resp = requests.post(
            url, auth=auth, json={"doc": update_fields},
            headers={"Content-Type": "application/json"}, timeout=30,
        )
        resp.raise_for_status()
        return True
    except Exception as e:
        logger.error(json.dumps({
            "event": "opensearch_update_error",
            "doc_id": doc_id,
            "error": str(e),
        }))
        return False


def _update_dynamodb_status(
    pipeline_id: str, stage: str, status: str,
    error_message: str | None = None,
    extra: dict[str, Any] | None = None,
):
    """DynamoDB rag-extraction-tasks 테이블에 분석 상태 업데이트."""
    try:
        table = dynamodb.Table(DYNAMODB_EXTRACTION_TABLE)
        item: dict[str, Any] = {
            "task_id": f"analysis_{pipeline_id}_{stage}",
            "pipeline_id": pipeline_id,
            "stage": stage,
            "status": status,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        if status == "in_progress":
            item["started_at"] = datetime.now(timezone.utc).isoformat()
        if error_message:
            item["error_message"] = error_message
        if extra:
            item.update(extra)
        table.put_item(Item=item)
    except Exception as e:
        logger.error(json.dumps({
            "event": "dynamodb_status_update_error",
            "pipeline_id": pipeline_id,
            "stage": stage,
            "error": str(e),
        }))


# ---------------------------------------------------------------------------
# Task 5.2: Hierarchy Extraction
# ---------------------------------------------------------------------------

def handle_hierarchy_extraction(event: dict[str, Any]) -> dict[str, Any]:
    """계층 트리 추출 핸들러.

    1. OpenSearch에서 pipeline_id의 모든 module_parse 문서 조회
    2. build_hierarchy() 호출
    3. JSON/CSV를 S3에 저장
    4. 계층 노드를 OpenSearch에 analysis_type=hierarchy로 인덱싱
    5. DynamoDB 상태 업데이트
    """
    pipeline_id = event["pipeline_id"]
    stage = "hierarchy_extraction"
    _update_dynamodb_status(pipeline_id, stage, "in_progress")

    try:
        # 1. OpenSearch에서 파싱된 모듈 조회
        parsed_docs = _opensearch_scroll_query(pipeline_id, "module_parse")
        if not parsed_docs:
            _update_dynamodb_status(pipeline_id, stage, "completed",
                                   extra={"modules_processed": 0})
            return {"status": "completed", "modules_processed": 0}

        # 모듈 데이터를 build_hierarchy 입력 형식으로 변환
        modules = []
        for doc in parsed_docs:
            modules.append({
                "module_name": doc.get("module_name", ""),
                "instance_list": doc.get("instance_list", ""),
                "port_list": doc.get("port_list", ""),
                "parameter_list": doc.get("parameter_list", ""),
                "file_path": doc.get("file_path", ""),
            })

        # 2. 계층 트리 구축
        tree = build_hierarchy(modules)

        # 3. S3에 JSON/CSV 저장
        if RTL_S3_BUCKET:
            json_key = f"rtl-parsed/hierarchy/{pipeline_id}/hierarchy_tree.json"
            csv_key = f"rtl-parsed/hierarchy/{pipeline_id}/hierarchy_tree.csv"
            s3_client.put_object(
                Bucket=RTL_S3_BUCKET, Key=json_key,
                Body=serialize_hierarchy_json(tree).encode("utf-8"),
                ContentType="application/json",
            )
            s3_client.put_object(
                Bucket=RTL_S3_BUCKET, Key=csv_key,
                Body=serialize_hierarchy_csv(tree).encode("utf-8"),
                ContentType="text/csv",
            )

        # 4. 계층 노드를 OpenSearch에 인덱싱
        indexed_count = 0

        def _index_nodes(nodes: list[dict], depth: int = 0):
            nonlocal indexed_count
            for node in nodes:
                doc = {
                    "pipeline_id": pipeline_id,
                    "analysis_type": "hierarchy",
                    "module_name": node.get("module_name", ""),
                    "instance_name": node.get("instance_name", ""),
                    "hierarchy_path": node.get("hierarchy_path", ""),
                    "hierarchy_depth": depth,
                    "clock_signals": node.get("clock_signals", []),
                    "reset_signals": node.get("reset_signals", []),
                    "memory_instances": node.get("memory_instances", []),
                    "children_modules": [
                        c.get("module_name", "") for c in node.get("children", [])
                    ],
                }
                _index_document(doc)
                indexed_count += 1
                _index_nodes(node.get("children", []), depth + 1)

        _index_nodes(tree)

        # 5. DynamoDB 상태 업데이트
        _update_dynamodb_status(pipeline_id, stage, "completed",
                               extra={"modules_processed": indexed_count})

        logger.info(json.dumps({
            "event": "hierarchy_extraction_complete",
            "pipeline_id": pipeline_id,
            "modules_processed": indexed_count,
        }))
        return {"status": "completed", "modules_processed": indexed_count}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "hierarchy_extraction_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


# ---------------------------------------------------------------------------
# Task 5.3: Clock Domain Analysis
# ---------------------------------------------------------------------------

def handle_clock_domain_analysis(event: dict[str, Any]) -> dict[str, Any]:
    """클럭 도메인 분석 핸들러.

    1. S3에서 RTL 소스 파일을 배치로 읽기
    2. extract_clock_domains() + classify_clock_domain() + detect_cdc_boundary()
    3. OpenSearch에 analysis_type=clock_domain 문서로 인덱싱
    4. DynamoDB 상태 업데이트
    """
    pipeline_id = event["pipeline_id"]
    stage = "clock_domain_analysis"
    _update_dynamodb_status(pipeline_id, stage, "in_progress")

    try:
        s3_prefix = event.get("s3_prefix", f"rtl-sources/{pipeline_id}/")
        files_processed = 0
        cdc_modules = 0

        # S3에서 RTL 파일 목록 조회 (배치 처리)
        paginator = s3_client.get_paginator("list_objects_v2")
        pages = paginator.paginate(Bucket=RTL_S3_BUCKET, Prefix=s3_prefix)

        batch: list[dict[str, str]] = []
        for page in pages:
            for obj in page.get("Contents", []):
                key = obj["Key"]
                if key.endswith((".v", ".sv", ".svh")):
                    batch.append({"key": key})

                    if len(batch) >= BATCH_SIZE:
                        processed, cdc = _process_clock_batch(
                            pipeline_id, batch,
                        )
                        files_processed += processed
                        cdc_modules += cdc
                        batch = []

        # 남은 배치 처리
        if batch:
            processed, cdc = _process_clock_batch(pipeline_id, batch)
            files_processed += processed
            cdc_modules += cdc

        _update_dynamodb_status(pipeline_id, stage, "completed",
                               extra={"modules_processed": files_processed,
                                      "cdc_modules": cdc_modules})

        logger.info(json.dumps({
            "event": "clock_domain_analysis_complete",
            "pipeline_id": pipeline_id,
            "files_processed": files_processed,
            "cdc_modules": cdc_modules,
        }))
        return {"status": "completed", "files_processed": files_processed,
                "cdc_modules": cdc_modules}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "clock_domain_analysis_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


def _process_clock_batch(
    pipeline_id: str, batch: list[dict[str, str]],
) -> tuple[int, int]:
    """클럭 도메인 분석 배치 처리."""
    processed = 0
    cdc_count = 0

    for item in batch:
        key = item["key"]
        try:
            resp = s3_client.get_object(Bucket=RTL_S3_BUCKET, Key=key)
            content = resp["Body"].read().decode("utf-8", errors="replace")
        except Exception as e:
            logger.warning(json.dumps({
                "event": "clock_s3_read_error", "key": key, "error": str(e),
            }))
            continue

        clocks = extract_clock_domains(content)
        if not clocks:
            processed += 1
            continue

        # 각 클럭 신호를 도메인으로 분류
        domain_entries: list[dict[str, Any]] = []
        domain_set: dict[str, list[str]] = {}
        for clk in clocks:
            domain = classify_clock_domain(clk)
            domain_set.setdefault(domain, []).append(clk)

        for domain, signals in domain_set.items():
            domain_entries.append({"domain": domain, "signals": signals})

        cdc_result = detect_cdc_boundary(domain_entries)

        # 파일명에서 모듈명 추정
        module_name = key.rsplit("/", 1)[-1].rsplit(".", 1)[0]

        doc = {
            "pipeline_id": pipeline_id,
            "analysis_type": "clock_domain",
            "module_name": module_name,
            "file_path": key,
            "clock_domains": domain_entries,
            "is_cdc_boundary": cdc_result["is_cdc_boundary"],
            "cdc_pairs": cdc_result["cdc_pairs"],
        }
        _index_document(doc)
        processed += 1
        if cdc_result["is_cdc_boundary"]:
            cdc_count += 1

    return processed, cdc_count


# ---------------------------------------------------------------------------
# Task 5.4: Dataflow Tracking
# ---------------------------------------------------------------------------

def handle_dataflow_tracking(event: dict[str, Any]) -> dict[str, Any]:
    """데이터 흐름 추적 핸들러.

    1. S3에서 RTL 소스 파일을 배치로 읽기
    2. build_dataflow_connections() 호출
    3. OpenSearch에 analysis_type=dataflow 문서로 인덱싱
    4. DynamoDB 상태 업데이트
    """
    pipeline_id = event["pipeline_id"]
    stage = "dataflow_tracking"
    _update_dynamodb_status(pipeline_id, stage, "in_progress")

    try:
        s3_prefix = event.get("s3_prefix", f"rtl-sources/{pipeline_id}/")
        files_processed = 0
        total_connections = 0

        paginator = s3_client.get_paginator("list_objects_v2")
        pages = paginator.paginate(Bucket=RTL_S3_BUCKET, Prefix=s3_prefix)

        batch: list[dict[str, str]] = []
        for page in pages:
            for obj in page.get("Contents", []):
                key = obj["Key"]
                if key.endswith((".v", ".sv", ".svh")):
                    batch.append({"key": key})

                    if len(batch) >= BATCH_SIZE:
                        processed, conns = _process_dataflow_batch(
                            pipeline_id, batch,
                        )
                        files_processed += processed
                        total_connections += conns
                        batch = []

        if batch:
            processed, conns = _process_dataflow_batch(pipeline_id, batch)
            files_processed += processed
            total_connections += conns

        _update_dynamodb_status(pipeline_id, stage, "completed",
                               extra={"modules_processed": files_processed,
                                      "total_connections": total_connections})

        logger.info(json.dumps({
            "event": "dataflow_tracking_complete",
            "pipeline_id": pipeline_id,
            "files_processed": files_processed,
            "total_connections": total_connections,
        }))
        return {"status": "completed", "files_processed": files_processed,
                "total_connections": total_connections}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "dataflow_tracking_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


def _process_dataflow_batch(
    pipeline_id: str, batch: list[dict[str, str]],
) -> tuple[int, int]:
    """데이터 흐름 분석 배치 처리."""
    processed = 0
    conn_count = 0

    for item in batch:
        key = item["key"]
        try:
            resp = s3_client.get_object(Bucket=RTL_S3_BUCKET, Key=key)
            content = resp["Body"].read().decode("utf-8", errors="replace")
        except Exception as e:
            logger.warning(json.dumps({
                "event": "dataflow_s3_read_error", "key": key, "error": str(e),
            }))
            continue

        connections = build_dataflow_connections(content)
        if not connections:
            processed += 1
            continue

        module_name = key.rsplit("/", 1)[-1].rsplit(".", 1)[0]

        doc = {
            "pipeline_id": pipeline_id,
            "analysis_type": "dataflow",
            "module_name": module_name,
            "file_path": key,
            "dataflow_connections": connections,
        }
        _index_document(doc)
        processed += 1
        conn_count += len(connections)

    return processed, conn_count


# ---------------------------------------------------------------------------
# Task 5.5: Topic Classification
# ---------------------------------------------------------------------------

def handle_topic_classification(event: dict[str, Any], context: Any = None) -> dict[str, Any]:
    """토픽 분류 핸들러 (배치 분할 실행 지원).

    8,107건 module_parse 문서를 300초 Lambda 타임아웃 내에서 처리하기 위해:
    - _update_document() 제거 (AOSS 부분 업데이트 비효율 + claim_generation이 직접 classify_topic 호출)
    - batch_offset 파라미터로 분할 실행
    - 남은 시간 < 30초 시 미처리분을 비동기 Lambda 호출로 위임

    1. OpenSearch에서 pipeline_id의 모든 module_parse 문서 조회
    2. batch_offset부터 classify_topic() 호출
    3. analysis_type=topic 문서만 인덱싱 (module_parse 업데이트 제거)
    4. 타임아웃 임박 시 비동기 분할 실행
    5. DynamoDB 상태 업데이트
    """
    pipeline_id = event["pipeline_id"]
    batch_offset = event.get("batch_offset", 0)
    stage = "topic_classification"

    if batch_offset == 0:
        _update_dynamodb_status(pipeline_id, stage, "in_progress")

    try:
        parsed_docs = _opensearch_scroll_query(pipeline_id, "module_parse")
        if not parsed_docs:
            _update_dynamodb_status(pipeline_id, stage, "completed",
                                   extra={"modules_processed": 0})
            return {"status": "completed", "modules_processed": 0}

        total_docs = len(parsed_docs)
        docs_to_process = parsed_docs[batch_offset:]

        logger.info(json.dumps({
            "event": "topic_classification_start_batch",
            "pipeline_id": pipeline_id,
            "batch_offset": batch_offset,
            "total_docs": total_docs,
            "remaining": len(docs_to_process),
        }))

        classified_count = 0
        unclassified_count = 0
        bulk_buffer: list[dict[str, Any]] = []
        BULK_SIZE = 200

        for i, doc in enumerate(docs_to_process):
            # 타임아웃 체크: 남은 시간 < 30초이면 미처리분 비동기 위임
            if context and hasattr(context, "get_remaining_time_in_millis"):
                remaining_ms = context.get_remaining_time_in_millis()
                if remaining_ms < 30000:
                    # 남은 bulk_buffer 플러시
                    if bulk_buffer:
                        _bulk_index_documents(bulk_buffer)
                        bulk_buffer = []
                    next_offset = batch_offset + i
                    logger.info(json.dumps({
                        "event": "topic_classification_timeout_split",
                        "pipeline_id": pipeline_id,
                        "processed_so_far": classified_count,
                        "next_offset": next_offset,
                        "remaining_docs": total_docs - next_offset,
                        "remaining_ms": remaining_ms,
                    }))
                    # 비동기 Lambda 호출로 나머지 처리
                    _invoke_async_continuation(
                        pipeline_id, stage, next_offset,
                    )
                    return {
                        "status": "split",
                        "classified": classified_count,
                        "next_offset": next_offset,
                        "remaining": total_docs - next_offset,
                    }

            module_name = doc.get("module_name", "")
            file_path = doc.get("file_path", "")

            topics = classify_topic(file_path, module_name)

            # analysis_type=topic 문서를 bulk 버퍼에 추가
            topic_doc = {
                "pipeline_id": pipeline_id,
                "analysis_type": "topic",
                "module_name": module_name,
                "file_path": file_path,
                "topic": topics,
                "topics": topics,
            }
            bulk_buffer.append(topic_doc)

            # bulk 버퍼가 BULK_SIZE에 도달하면 일괄 인덱싱
            if len(bulk_buffer) >= BULK_SIZE:
                _bulk_index_documents(bulk_buffer)
                bulk_buffer = []

            classified_count += 1
            if topics == ["unclassified"]:
                unclassified_count += 1

        # 남은 bulk_buffer 플러시
        if bulk_buffer:
            _bulk_index_documents(bulk_buffer)

        total_classified = batch_offset + classified_count
        _update_dynamodb_status(pipeline_id, stage, "completed",
                               extra={"modules_processed": total_classified,
                                      "unclassified_count": unclassified_count})

        logger.info(json.dumps({
            "event": "topic_classification_complete",
            "pipeline_id": pipeline_id,
            "batch_offset": batch_offset,
            "classified_this_batch": classified_count,
            "total_classified": total_classified,
            "unclassified": unclassified_count,
        }))
        return {"status": "completed", "classified": total_classified,
                "unclassified": unclassified_count}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "topic_classification_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


def _invoke_async_continuation(
    pipeline_id: str, stage: str, batch_offset: int,
) -> None:
    """미처리분을 비동기 Lambda 호출로 위임."""
    try:
        lambda_client = boto3.client("lambda")
        function_name = os.environ.get("AWS_LAMBDA_FUNCTION_NAME", "")
        if not function_name:
            logger.error("AWS_LAMBDA_FUNCTION_NAME not set, cannot split")
            return

        payload = json.dumps({
            "stage": stage,
            "pipeline_id": pipeline_id,
            "batch_offset": batch_offset,
        })
        lambda_client.invoke(
            FunctionName=function_name,
            InvocationType="Event",  # 비동기
            Payload=payload.encode("utf-8"),
        )
        logger.info(json.dumps({
            "event": "async_continuation_invoked",
            "pipeline_id": pipeline_id,
            "stage": stage,
            "batch_offset": batch_offset,
        }))
    except Exception as e:
        logger.error(json.dumps({
            "event": "async_continuation_error",
            "pipeline_id": pipeline_id,
            "stage": stage,
            "error": str(e),
        }))


# ---------------------------------------------------------------------------
# Task 7.4: Claim Generation
# ---------------------------------------------------------------------------

def handle_claim_generation(event: dict[str, Any]) -> dict[str, Any]:
    """Claim 생성 핸들러.

    module_parse 문서에서 직접 classify_topic()을 호출하여 토픽별로 그룹화한 뒤
    generate_claims()로 Claim을 생성한다. topic 문서에 의존하지 않는다.

    event에 ``topic`` 파라미터가 있으면 해당 토픽만 처리한다.
    없으면 전체 토픽을 처리하되, 300초 타임아웃 내에서 가능한 만큼만.
    """
    pipeline_id = event["pipeline_id"]
    target_topic = event.get("topic", "")  # 단일 토픽 지정 시
    stage = "claim_generation"
    _update_dynamodb_status(pipeline_id, stage, "in_progress")

    try:
        parsed_docs = _opensearch_scroll_query(pipeline_id, "module_parse")

        # 분석 결과 수집 (hierarchy만 — 가볍게)
        hierarchy_docs = _opensearch_scroll_query(pipeline_id, "hierarchy", max_docs=100)
        analysis_results: dict[str, Any] = {
            "hierarchy": hierarchy_docs[0] if hierarchy_docs else {},
            "clock_domains": [],
            "dataflow": [],
        }

        # module_parse 문서에서 직접 토픽 분류 → 토픽별 그룹화
        topic_groups: dict[str, list[dict[str, Any]]] = {}
        for doc in parsed_docs:
            name = doc.get("module_name", "")
            file_path = doc.get("file_path", "")
            if not name:
                continue
            topics = classify_topic(file_path, name)
            for t in topics:
                if t != "unclassified":
                    topic_groups.setdefault(t, []).append(doc)

        logger.info(json.dumps({
            "event": "claim_topic_groups",
            "pipeline_id": pipeline_id,
            "target_topic": target_topic or "all",
            "topics": {t: len(mods) for t, mods in topic_groups.items()},
        }))

        # 단일 토픽 지정 시 해당 토픽만 처리
        if target_topic:
            topics_to_process = {target_topic: topic_groups.get(target_topic, [])}
        else:
            topics_to_process = topic_groups

        total_claims = 0
        for topic, modules in topics_to_process.items():
            if not modules:
                continue
            modules_subset = modules[:20]
            claims = generate_claims(pipeline_id, topic, modules_subset, analysis_results)

            for claim in claims:
                claim["analysis_type"] = "claim"
                _index_document(claim)
                total_claims += 1

        _update_dynamodb_status(pipeline_id, stage, "completed",
                               extra={"claims_generated": total_claims})

        logger.info(json.dumps({
            "event": "claim_generation_complete",
            "pipeline_id": pipeline_id,
            "claims_generated": total_claims,
        }))
        return {"status": "completed", "claims_generated": total_claims}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "claim_generation_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


# ---------------------------------------------------------------------------
# Task 7.4: HDD Generation
# ---------------------------------------------------------------------------

def handle_hdd_generation(event: dict[str, Any]) -> dict[str, Any]:
    """HDD 섹션 생성 핸들러.

    event에 ``topic`` 파라미터가 있으면 해당 토픽만 처리.
    없으면 전체 토픽을 처리하되, 300초 타임아웃 내에서 가능한 만큼.

    1. 분석 결과 수집 (hierarchy, clock_domains, dataflow, claims)
    2. generate_hdd_section() 호출
    3. S3에 Markdown 저장 + OpenSearch 인덱싱
    """
    pipeline_id = event["pipeline_id"]
    target_topic = event.get("topic", "")
    stage = "hdd_generation"
    _update_dynamodb_status(pipeline_id, stage, "in_progress")

    try:
        # 분석 결과 수집
        hierarchy_docs = _opensearch_scroll_query(pipeline_id, "hierarchy")
        clock_docs = _opensearch_scroll_query(pipeline_id, "clock_domain")
        dataflow_docs = _opensearch_scroll_query(pipeline_id, "dataflow")

        # claim 전체를 한 번만 조회 (루프 밖)
        all_claim_docs = _opensearch_scroll_query(pipeline_id, "claim")

        # 심화 분석 결과 5종 조회 (조회 실패 시 빈 리스트로 폴백)
        deep_analysis: dict[str, Any] = {}
        for atype in ("chip_config", "edc_topology", "noc_protocol",
                       "overlay_deep", "sram_inventory"):
            try:
                docs = _opensearch_scroll_query(pipeline_id, atype, max_docs=100)
                if docs:
                    deep_analysis[atype] = docs
            except Exception as da_err:
                logger.warning(json.dumps({
                    "event": "deep_analysis_query_fallback",
                    "pipeline_id": pipeline_id,
                    "analysis_type": atype,
                    "error": str(da_err),
                }))

        # 토픽 목록: target_topic 지정 시 해당 토픽만
        if target_topic:
            topics_to_generate = {target_topic}
        else:
            topic_docs = _opensearch_scroll_query(pipeline_id, "topic")
            topics_to_generate: set[str] = set()
            for doc in topic_docs:
                t_list = doc.get("topics", doc.get("topic", []))
                if isinstance(t_list, str):
                    t_list = [t_list]
                for t in t_list:
                    if t != "unclassified":
                        topics_to_generate.add(t)

        hierarchy = hierarchy_docs[0] if hierarchy_docs else {}
        sections_generated = 0

        # 토픽별 module_parse 문서 수집 (claim 편중 문제 우회)
        parsed_docs = _opensearch_scroll_query(pipeline_id, "module_parse")
        topic_module_map: dict[str, list[dict[str, Any]]] = {}
        for doc in parsed_docs:
            name = doc.get("module_name", "")
            fp = doc.get("file_path", "")
            if not name:
                continue
            doc_topics = classify_topic(fp, name)
            for t in doc_topics:
                if t != "unclassified":
                    topic_module_map.setdefault(t, []).append(doc)

        logger.info(json.dumps({
            "event": "hdd_generation_topics",
            "pipeline_id": pipeline_id,
            "target_topic": target_topic or "all",
            "topics": sorted(topics_to_generate),
        }))

        for topic in sorted(topics_to_generate):
            # claim을 토픽별로 필터 (이미 조회한 전체에서)
            claim_docs = [d for d in all_claim_docs if d.get("topic") == topic]

            # 토픽별 module_parse 데이터를 hierarchy에 보강
            topic_modules = topic_module_map.get(topic, [])
            topic_hierarchy = dict(hierarchy) if isinstance(hierarchy, dict) else {}
            if topic_modules:
                # 토픽 대표 모듈 정보를 hierarchy에 추가
                topic_hierarchy["topic_modules"] = [
                    {
                        "module_name": m.get("module_name", ""),
                        "port_list": m.get("port_list", "")[:500],
                        "instance_list": m.get("instance_list", "")[:500],
                        "parameter_list": m.get("parameter_list", "")[:300],
                        "file_path": m.get("file_path", ""),
                    }
                    for m in topic_modules[:15]  # 토픽당 최대 15개 모듈
                ]
                topic_hierarchy["topic_module_count"] = len(topic_modules)

            try:
                result = generate_hdd_section(
                    pipeline_id, topic, topic_hierarchy,
                    clock_docs, dataflow_docs, claim_docs,
                    deep_analysis=deep_analysis if deep_analysis else None,
                )
            except RuntimeError as e:
                logger.error("HDD generation failed for topic=%s: %s", topic, e)
                continue

            # S3에 Markdown 저장
            if RTL_S3_BUCKET:
                s3_key = f"rtl-parsed/hdd/{pipeline_id}/{topic}_HDD.md"
                s3_client.put_object(
                    Bucket=RTL_S3_BUCKET, Key=s3_key,
                    Body=result["hdd_content"].encode("utf-8"),
                    ContentType="text/markdown",
                )

            # OpenSearch 인덱싱
            _index_document(result)
            sections_generated += 1

        _update_dynamodb_status(pipeline_id, stage, "completed",
                               extra={"sections_generated": sections_generated})

        logger.info(json.dumps({
            "event": "hdd_generation_complete",
            "pipeline_id": pipeline_id,
            "sections_generated": sections_generated,
        }))
        return {"status": "completed", "sections_generated": sections_generated}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "hdd_generation_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


# ---------------------------------------------------------------------------
# Task 9.1: Variant Delta Analysis
# ---------------------------------------------------------------------------

def handle_variant_delta(event: dict[str, Any]) -> dict[str, Any]:
    """Variant delta 분석 핸들러.

    1. event에서 variant_baseline_id 파라미터 읽기
    2. 베이스라인과 variant의 module_parse 문서를 OpenSearch에서 조회
    3. extract_variant_delta() 호출
    4. 결과를 OpenSearch에 analysis_type=variant_delta 문서로 인덱싱
    """
    pipeline_id = event["pipeline_id"]
    variant_baseline_id = event.get("variant_baseline_id", "")
    stage = "variant_delta"
    _update_dynamodb_status(pipeline_id, stage, "in_progress")

    try:
        if not variant_baseline_id:
            _update_dynamodb_status(pipeline_id, stage, "completed",
                                   extra={"skipped": True,
                                          "reason": "no variant_baseline_id"})
            return {"status": "completed", "skipped": True}

        # 베이스라인과 variant 모듈 조회
        baseline_docs = _opensearch_scroll_query(variant_baseline_id, "module_parse")
        variant_docs = _opensearch_scroll_query(pipeline_id, "module_parse")

        delta = extract_variant_delta(baseline_docs, variant_docs)

        # OpenSearch에 인덱싱
        delta_doc: dict[str, Any] = {
            "pipeline_id": pipeline_id,
            "analysis_type": "variant_delta",
            "variant_baseline_id": variant_baseline_id,
            "added_modules": delta["added_modules"],
            "removed_modules": delta["removed_modules"],
            "parameter_changes": delta["parameter_changes"],
            "instance_changes": delta["instance_changes"],
        }
        _index_document(delta_doc)

        summary = {
            "added": len(delta["added_modules"]),
            "removed": len(delta["removed_modules"]),
            "param_changes": len(delta["parameter_changes"]),
            "instance_changes": len(delta["instance_changes"]),
        }

        _update_dynamodb_status(pipeline_id, stage, "completed", extra=summary)

        logger.info(json.dumps({
            "event": "variant_delta_complete",
            "pipeline_id": pipeline_id,
            "baseline_id": variant_baseline_id,
            **summary,
        }))
        return {"status": "completed", **summary}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "variant_delta_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


# ---------------------------------------------------------------------------
# Backfill: 기존 문서에 pipeline_id, analysis_type 필드 추가
# ---------------------------------------------------------------------------

def handle_backfill_pipeline_id(event: dict[str, Any]) -> dict[str, Any]:
    """기존 OpenSearch 문서에 pipeline_id, analysis_type 필드를 백필.

    AOSS는 _update_by_query를 지원하지 않으므로:
    1. pipeline_id 필드가 없는 문서를 검색 (must_not exists)
    2. 각 문서에 pipeline_id, chip_type, snapshot_date, analysis_type 추가
    3. 새 문서로 다시 인덱싱 (POST /_doc)

    배치 처리: 100건씩

    Args:
        event: 백필 이벤트.
            필수: ``pipeline_id`` (str)
            선택: ``analysis_type`` (str, 기본값 "module_parse")

    Returns:
        백필 결과 dict.
    """
    import requests

    pipeline_id = event.get("pipeline_id", "tt_20260221")
    analysis_type = event.get("analysis_type", "module_parse")
    stage = "backfill_pipeline_id"
    _update_dynamodb_status(pipeline_id, stage, "in_progress")

    # pipeline_id에서 chip_type, snapshot_date 추출
    if "_" in pipeline_id:
        chip_type, snapshot_date = pipeline_id.split("_", 1)
    else:
        chip_type, snapshot_date = pipeline_id, "unknown"

    total_backfilled = 0
    total_failed = 0

    try:
        if not OPENSEARCH_ENDPOINT:
            logger.warning("OPENSEARCH_ENDPOINT not set, skipping backfill")
            _update_dynamodb_status(pipeline_id, stage, "completed",
                                   extra={"backfilled": 0, "skipped": True})
            return {"status": "completed", "backfilled": 0, "failed": 0,
                    "skipped": True}

        auth = _get_opensearch_auth()
        url = f"{OPENSEARCH_ENDPOINT}/{OPENSEARCH_INDEX}/_search"

        while True:
            # pipeline_id 필드가 없는 문서를 배치로 검색
            search_body: dict[str, Any] = {
                "size": BATCH_SIZE,
                "query": {
                    "bool": {
                        "must_not": [
                            {"exists": {"field": "pipeline_id"}},
                        ],
                    },
                },
            }

            resp = requests.post(
                url, auth=auth, json=search_body,
                headers={"Content-Type": "application/json"}, timeout=60,
            )
            resp.raise_for_status()
            data = resp.json()
            hits = data.get("hits", {}).get("hits", [])

            if not hits:
                break

            for hit in hits:
                source = hit.get("_source", {})
                # 기존 문서에 새 필드 추가
                source["pipeline_id"] = pipeline_id
                source["chip_type"] = chip_type
                source["snapshot_date"] = snapshot_date
                source["analysis_type"] = analysis_type

                if _index_document(source):
                    total_backfilled += 1
                else:
                    total_failed += 1

            logger.info(json.dumps({
                "event": "backfill_batch_complete",
                "pipeline_id": pipeline_id,
                "batch_size": len(hits),
                "total_backfilled": total_backfilled,
            }))

        _update_dynamodb_status(pipeline_id, stage, "completed",
                               extra={"backfilled": total_backfilled,
                                      "failed": total_failed})

        logger.info(json.dumps({
            "event": "backfill_pipeline_id_complete",
            "pipeline_id": pipeline_id,
            "total_backfilled": total_backfilled,
            "total_failed": total_failed,
        }))
        return {"status": "completed", "backfilled": total_backfilled,
                "failed": total_failed}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "backfill_pipeline_id_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


# ---------------------------------------------------------------------------
# Clear Index: OpenSearch 인덱스 삭제 후 재생성
# ---------------------------------------------------------------------------

def handle_clear_index(event: dict[str, Any]) -> dict[str, Any]:
    """OpenSearch 인덱스 정리.

    ``analysis_type`` 파라미터가 지정되면 해당 타입 문서만 개별 삭제.
    지정되지 않으면 인덱스 전체를 삭제하고 재생성.

    AOSS는 ``_delete_by_query``를 지원하지 않으므로:
    - 전체 삭제: 인덱스 DELETE → PUT 재생성
    - 부분 삭제: scroll 조회 → 개별 문서 DELETE

    Args:
        event: ``pipeline_id`` (str) 필수, ``analysis_type`` (str) 선택.

    Returns:
        ``{"status": "completed"}`` 또는 에러 시 raise.
    """
    import requests

    pipeline_id = event["pipeline_id"]
    target_analysis_type = event.get("analysis_type", "")
    stage = "clear_index"
    _update_dynamodb_status(pipeline_id, stage, "in_progress")

    try:
        if not OPENSEARCH_ENDPOINT:
            logger.warning("OPENSEARCH_ENDPOINT not set, skipping clear_index")
            _update_dynamodb_status(pipeline_id, stage, "completed",
                                   extra={"skipped": True})
            return {"status": "completed", "skipped": True}

        auth = _get_opensearch_auth()

        # analysis_type이 지정되면 해당 타입 문서만 개별 삭제
        if target_analysis_type:
            docs = _opensearch_scroll_query(
                pipeline_id, target_analysis_type, max_docs=50000,
            )
            deleted = 0
            for doc in docs:
                doc_id = doc.get("_id", "")
                if not doc_id:
                    continue
                del_url = (
                    f"{OPENSEARCH_ENDPOINT}/{OPENSEARCH_INDEX}/_doc/{doc_id}"
                )
                try:
                    resp = requests.delete(
                        del_url, auth=auth,
                        headers={"Content-Type": "application/json"},
                        timeout=30,
                    )
                    if resp.status_code in (200, 404):
                        deleted += 1
                except Exception as del_err:
                    logger.warning(json.dumps({
                        "event": "clear_index_doc_delete_error",
                        "doc_id": doc_id,
                        "error": str(del_err),
                    }))

            logger.info(json.dumps({
                "event": "clear_index_partial",
                "pipeline_id": pipeline_id,
                "analysis_type": target_analysis_type,
                "docs_found": len(docs),
                "docs_deleted": deleted,
            }))
            _update_dynamodb_status(pipeline_id, stage, "completed",
                                   extra={"deleted": deleted,
                                          "analysis_type": target_analysis_type})
            return {"status": "completed", "deleted": deleted}

        # analysis_type 미지정 → 인덱스 전체 삭제/재생성
        index_url = f"{OPENSEARCH_ENDPOINT}/{OPENSEARCH_INDEX}"

        # 1. DELETE /{index}
        del_resp = requests.delete(
            index_url, auth=auth,
            headers={"Content-Type": "application/json"}, timeout=30,
        )
        # 404 = 인덱스가 이미 없음 → 무시
        if del_resp.status_code not in (200, 404):
            del_resp.raise_for_status()
        logger.info(json.dumps({
            "event": "clear_index_deleted",
            "index": OPENSEARCH_INDEX,
            "status_code": del_resp.status_code,
        }))

        # 2. PUT /{index} — 매핑 재생성
        index_body: dict[str, Any] = {
            "settings": {
                "index": {
                    "knn": True,
                },
            },
            "mappings": {
                "properties": {
                    "embedding": {
                        "type": "knn_vector",
                        "dimension": 1024,
                        "method": {
                            "name": "hnsw",
                            "space_type": "cosinesimil",
                            "engine": "faiss",
                        },
                    },
                    "module_name": {"type": "keyword"},
                    "parent_module": {"type": "keyword"},
                    "file_path": {"type": "keyword"},
                    "port_list": {"type": "text"},
                    "parameter_list": {"type": "text"},
                    "instance_list": {"type": "text"},
                    "parsed_summary": {"type": "text"},
                    "pipeline_id": {"type": "keyword"},
                    "chip_type": {"type": "keyword"},
                    "snapshot_date": {"type": "keyword"},
                    "analysis_type": {"type": "keyword"},
                    "hierarchy_path": {"type": "keyword"},
                    "clock_domains": {"type": "nested"},
                    "is_cdc_boundary": {"type": "boolean"},
                    "topic": {"type": "keyword"},
                    "topics": {"type": "keyword"},
                    "claim_id": {"type": "keyword"},
                    "claim_type": {"type": "keyword"},
                    "claim_text": {"type": "text"},
                    "hdd_content": {"type": "text"},
                    "created_at": {"type": "date"},
                    "updated_at": {"type": "date"},
                },
            },
        }

        put_resp = requests.put(
            index_url, auth=auth, json=index_body,
            headers={"Content-Type": "application/json"}, timeout=30,
        )
        put_resp.raise_for_status()
        logger.info(json.dumps({
            "event": "clear_index_recreated",
            "index": OPENSEARCH_INDEX,
            "status_code": put_resp.status_code,
        }))

        _update_dynamodb_status(pipeline_id, stage, "completed")
        return {"status": "completed"}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "clear_index_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


# ---------------------------------------------------------------------------
# Reparse All: S3 파일 목록으로 Lambda 재트리거
# ---------------------------------------------------------------------------

def handle_reparse_all(event: dict[str, Any]) -> dict[str, Any]:
    """S3의 RTL 파일 목록을 읽어서 각 파일에 대해 Lambda를 비동기 invoke.

    1. ``list_objects_v2``로 ``s3_prefix`` 경로의 ``.v/.sv/.svh`` 파일 목록 조회
    2. 각 파일에 대해 S3 Event 형식의 payload 구성
    3. Lambda를 비동기(``InvocationType=Event``)로 invoke
    4. 배치 처리: 100개씩

    Args:
        event: ``pipeline_id`` (str) 필수, ``s3_prefix`` (str) 선택.

    Returns:
        ``{"status": "completed", "files_triggered": int, "errors": int}``
    """
    pipeline_id = event["pipeline_id"]
    s3_prefix = event.get("s3_prefix", f"rtl-sources/{pipeline_id}/")
    stage = "reparse_all"
    _update_dynamodb_status(pipeline_id, stage, "in_progress")

    bucket_name = RTL_S3_BUCKET or "bos-ai-rtl-src-533335672315"
    function_name = os.environ.get(
        "AWS_LAMBDA_FUNCTION_NAME", "lambda-rtl-parser-seoul-dev",
    )
    lambda_client = boto3.client("lambda", region_name="ap-northeast-2")

    files_triggered = 0
    errors = 0

    try:
        paginator = s3_client.get_paginator("list_objects_v2")
        pages = paginator.paginate(Bucket=bucket_name, Prefix=s3_prefix)

        batch: list[str] = []
        for page in pages:
            for obj in page.get("Contents", []):
                key = obj["Key"]
                if key.endswith((".v", ".sv", ".svh")):
                    batch.append(key)

                    if len(batch) >= BATCH_SIZE:
                        triggered, errs = _invoke_reparse_batch(
                            lambda_client, function_name, bucket_name, batch,
                        )
                        files_triggered += triggered
                        errors += errs
                        batch = []

        # 남은 배치 처리
        if batch:
            triggered, errs = _invoke_reparse_batch(
                lambda_client, function_name, bucket_name, batch,
            )
            files_triggered += triggered
            errors += errs

        _update_dynamodb_status(pipeline_id, stage, "completed",
                               extra={"files_triggered": files_triggered,
                                      "errors": errors})

        logger.info(json.dumps({
            "event": "reparse_all_complete",
            "pipeline_id": pipeline_id,
            "files_triggered": files_triggered,
            "errors": errors,
        }))
        return {"status": "completed", "files_triggered": files_triggered,
                "errors": errors}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "reparse_all_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


def _invoke_reparse_batch(
    lambda_client: Any,
    function_name: str,
    bucket_name: str,
    keys: list[str],
) -> tuple[int, int]:
    """배치 내 각 파일에 대해 Lambda를 비동기 invoke."""
    triggered = 0
    errs = 0
    for key in keys:
        s3_event = {
            "Records": [{
                "s3": {
                    "bucket": {"name": bucket_name},
                    "object": {"key": key},
                },
            }],
        }
        try:
            lambda_client.invoke(
                FunctionName=function_name,
                InvocationType="Event",
                Payload=json.dumps(s3_event).encode(),
            )
            triggered += 1
        except Exception as e:
            errs += 1
            logger.warning(json.dumps({
                "event": "reparse_invoke_error",
                "key": key,
                "error": str(e),
            }))
    return triggered, errs


# ---------------------------------------------------------------------------
# Task 11.2: Chip Config (Package Parameter Extraction)
# ---------------------------------------------------------------------------

def handle_chip_config(event: dict[str, Any]) -> dict[str, Any]:
    """패키지 파라미터 추출 및 칩 구성 분석 핸들러.

    1. OpenSearch module_parse 문서에서 *_pkg.sv 파일 경로만 추출 (S3 ListObjects 최소화)
    2. extract_package_params() + identify_chip_config() + extract_enum_mapping()
    3. OpenSearch에 analysis_type=chip_config 문서로 인덱싱
    4. DynamoDB 상태 업데이트
    """
    pipeline_id = event["pipeline_id"]
    stage = "chip_config"
    topic_filter = event.get("topic_filter", "")  # 분할 실행 시 토픽 필터
    _update_dynamodb_status(pipeline_id, stage, "in_progress")

    try:
        # OpenSearch에서 *_pkg.sv 파일만 직접 쿼리 (module_parse 전체 조회 대신)
        import requests as _requests
        pkg_files: list[str] = []

        if OPENSEARCH_ENDPOINT:
            auth = _get_opensearch_auth()
            url = f"{OPENSEARCH_ENDPOINT}/{OPENSEARCH_INDEX}/_search"
            search_body = {
                "size": 200,
                "query": {
                    "bool": {
                        "must": [
                            {"term": {"pipeline_id": pipeline_id}},
                            {"term": {"analysis_type": "module_parse"}},
                            {"wildcard": {"file_path": "*_pkg.sv"}},
                        ],
                    },
                },
                "_source": ["file_path"],
            }
            try:
                resp = _requests.post(
                    url, auth=auth, json=search_body,
                    headers={"Content-Type": "application/json"}, timeout=30,
                )
                resp.raise_for_status()
                hits = resp.json().get("hits", {}).get("hits", [])
                for hit in hits:
                    fp = hit.get("_source", {}).get("file_path", "")
                    if fp and fp.endswith("_pkg.sv"):
                        if topic_filter:
                            fname = fp.rsplit("/", 1)[-1].lower()
                            if not fname.startswith(topic_filter.lower()):
                                continue
                        pkg_files.append(fp)
            except Exception as q_err:
                logger.warning(json.dumps({
                    "event": "chip_config_query_error",
                    "pipeline_id": pipeline_id,
                    "error": str(q_err),
                }))

        logger.info(json.dumps({
            "event": "chip_config_pkg_files_found",
            "pipeline_id": pipeline_id,
            "topic_filter": topic_filter or "all",
            "pkg_file_count": len(pkg_files),
        }))

        files_processed = 0
        for key in pkg_files:
            try:
                resp = s3_client.get_object(Bucket=RTL_S3_BUCKET, Key=key)
                content = resp["Body"].read().decode("utf-8", errors="replace")
            except Exception as e:
                logger.warning(json.dumps({
                    "event": "chip_config_s3_read_error",
                    "key": key, "error": str(e),
                }))
                continue

            params = extract_package_params(content)
            chip_config = identify_chip_config(params)
            enum_mapping = extract_enum_mapping(content)

            pkg_name = key.rsplit("/", 1)[-1]
            doc = {
                "pipeline_id": pipeline_id,
                "analysis_type": "chip_config",
                "package_file": pkg_name,
                "file_path": key,
                "parameters": chip_config.get("chip_params", {}),
                "grid_size": chip_config.get("grid_size", {}),
                "enums": enum_mapping,
                "all_localparams": params.get("localparams", {}),
                "all_parameters": params.get("parameters", {}),
            }
            _index_document(doc)
            files_processed += 1

        _update_dynamodb_status(pipeline_id, stage, "completed",
                               extra={"files_processed": files_processed})

        logger.info(json.dumps({
            "event": "chip_config_complete",
            "pipeline_id": pipeline_id,
            "files_processed": files_processed,
        }))
        return {"status": "completed", "files_processed": files_processed}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "chip_config_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


# ---------------------------------------------------------------------------
# Task 11.5: EDC Topology Analysis
# ---------------------------------------------------------------------------

def handle_edc_topology(event: dict[str, Any]) -> dict[str, Any]:
    """EDC 토폴로지 분석 핸들러.

    1. OpenSearch에서 EDC 관련 모듈 조회
    2. build_edc_topology() + identify_harvest_bypass() + build_node_id_table()
    3. S3에서 tt_edc1_pkg.sv 읽어 extract_serial_bus_interface()
    4. OpenSearch에 analysis_type=edc_topology 문서로 인덱싱
    5. DynamoDB 상태 업데이트
    """
    pipeline_id = event["pipeline_id"]
    stage = "edc_topology"
    _update_dynamodb_status(pipeline_id, stage, "in_progress")

    try:
        # OpenSearch에서 EDC 모듈 조회
        parsed_docs = _opensearch_scroll_query(pipeline_id, "module_parse")
        edc_modules = [
            d for d in parsed_docs
            if d.get("module_name", "").lower().startswith("tt_edc")
        ]

        if not edc_modules:
            _update_dynamodb_status(pipeline_id, stage, "completed",
                                   extra={"modules_processed": 0})
            return {"status": "completed", "modules_processed": 0}

        topology = build_edc_topology(edc_modules)
        bypass_paths = identify_harvest_bypass(edc_modules)
        node_table = build_node_id_table(edc_modules)

        # S3에서 tt_edc1_pkg.sv 읽기
        serial_bus: dict[str, Any] = {"signals": []}
        s3_prefix = event.get("s3_prefix", f"rtl-sources/{pipeline_id}/")
        try:
            paginator = s3_client.get_paginator("list_objects_v2")
            pages = paginator.paginate(Bucket=RTL_S3_BUCKET, Prefix=s3_prefix)
            for page in pages:
                for obj in page.get("Contents", []):
                    key = obj["Key"]
                    if "edc" in key.lower() and key.endswith("_pkg.sv"):
                        resp = s3_client.get_object(Bucket=RTL_S3_BUCKET, Key=key)
                        pkg_content = resp["Body"].read().decode("utf-8", errors="replace")
                        serial_bus = extract_serial_bus_interface(pkg_content)
                        break
                if serial_bus.get("signals"):
                    break
        except Exception as e:
            logger.warning(json.dumps({
                "event": "edc_pkg_read_error", "error": str(e),
            }))

        doc = {
            "pipeline_id": pipeline_id,
            "analysis_type": "edc_topology",
            "ring_topology": {
                "segment_a": topology.get("segment_a", []),
                "u_turn": topology.get("u_turn", ""),
                "segment_b": topology.get("segment_b", []),
            },
            "harvest_bypass_paths": bypass_paths,
            "serial_bus_interface": serial_bus,
            "node_id_table": node_table,
            "connections": topology.get("connections", []),
        }
        _index_document(doc)

        _update_dynamodb_status(pipeline_id, stage, "completed",
                               extra={"modules_processed": len(edc_modules)})

        logger.info(json.dumps({
            "event": "edc_topology_complete",
            "pipeline_id": pipeline_id,
            "modules_processed": len(edc_modules),
        }))
        return {"status": "completed", "modules_processed": len(edc_modules)}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "edc_topology_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


# ---------------------------------------------------------------------------
# Task 11.8: NoC Protocol Analysis
# ---------------------------------------------------------------------------

def handle_noc_protocol(event: dict[str, Any]) -> dict[str, Any]:
    """NoC 프로토콜 분석 핸들러.

    1. S3에서 tt_noc_pkg.sv 읽기
    2. extract_routing_algorithms() + extract_flit_structure() + extract_axi_address_gasket()
    3. OpenSearch에서 NoC 모듈 조회 → identify_security_fence()
    4. OpenSearch에 analysis_type=noc_protocol 문서로 인덱싱
    5. DynamoDB 상태 업데이트
    """
    pipeline_id = event["pipeline_id"]
    stage = "noc_protocol"
    _update_dynamodb_status(pipeline_id, stage, "in_progress")

    try:
        s3_prefix = event.get("s3_prefix", f"rtl-sources/{pipeline_id}/")
        pkg_content = ""

        # S3에서 tt_noc_pkg.sv 읽기
        try:
            paginator = s3_client.get_paginator("list_objects_v2")
            pages = paginator.paginate(Bucket=RTL_S3_BUCKET, Prefix=s3_prefix)
            for page in pages:
                for obj in page.get("Contents", []):
                    key = obj["Key"]
                    if "noc" in key.lower() and key.endswith("_pkg.sv"):
                        resp = s3_client.get_object(Bucket=RTL_S3_BUCKET, Key=key)
                        pkg_content = resp["Body"].read().decode("utf-8", errors="replace")
                        break
                if pkg_content:
                    break
        except Exception as e:
            logger.warning(json.dumps({
                "event": "noc_pkg_read_error", "error": str(e),
            }))

        routing = extract_routing_algorithms(pkg_content) if pkg_content else []
        flit = extract_flit_structure(pkg_content) if pkg_content else {}
        axi_gasket = extract_axi_address_gasket(pkg_content) if pkg_content else {}

        # OpenSearch에서 NoC 모듈 조회 → 보안 펜스 식별
        parsed_docs = _opensearch_scroll_query(pipeline_id, "module_parse")
        noc_modules = [
            d for d in parsed_docs
            if d.get("module_name", "").lower().startswith("tt_noc")
        ]
        security = identify_security_fence(noc_modules)

        doc = {
            "pipeline_id": pipeline_id,
            "analysis_type": "noc_protocol",
            "routing_algorithms": routing,
            "flit_structure": flit,
            "axi_address_gasket": axi_gasket,
            "security_fence": security,
        }
        _index_document(doc)

        _update_dynamodb_status(pipeline_id, stage, "completed",
                               extra={"noc_modules": len(noc_modules)})

        logger.info(json.dumps({
            "event": "noc_protocol_complete",
            "pipeline_id": pipeline_id,
            "routing_algorithms": len(routing),
            "noc_modules": len(noc_modules),
        }))
        return {"status": "completed", "noc_modules": len(noc_modules),
                "routing_algorithms": len(routing)}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "noc_protocol_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


# ---------------------------------------------------------------------------
# Task 11.11: Overlay Deep Analysis
# ---------------------------------------------------------------------------

def handle_overlay_deep_analysis(event: dict[str, Any]) -> dict[str, Any]:
    """Overlay 심화 분석 핸들러.

    1. S3에서 tt_overlay_pkg.sv 읽기 → extract_cpu_cluster_params()
    2. OpenSearch에서 Overlay 모듈 조회 → identify_submodule_roles()
    3. S3에서 tt_overlay_memory_wrapper 읽기 → extract_l1_cache_params()
    4. S3에서 tt_overlay_reg_xbar_slave_decode 읽기 → extract_apb_slaves()
    5. OpenSearch에 analysis_type=overlay_deep 문서로 인덱싱
    6. DynamoDB 상태 업데이트
    """
    pipeline_id = event["pipeline_id"]
    stage = "overlay_deep_analysis"
    _update_dynamodb_status(pipeline_id, stage, "in_progress")

    try:
        s3_prefix = event.get("s3_prefix", f"rtl-sources/{pipeline_id}/")

        # S3에서 overlay 관련 파일 읽기
        pkg_content = ""
        memory_content = ""
        xbar_content = ""

        try:
            paginator = s3_client.get_paginator("list_objects_v2")
            pages = paginator.paginate(Bucket=RTL_S3_BUCKET, Prefix=s3_prefix)
            for page in pages:
                for obj in page.get("Contents", []):
                    key = obj["Key"]
                    lower_key = key.lower()
                    if "overlay" in lower_key and key.endswith("_pkg.sv") and not pkg_content:
                        resp = s3_client.get_object(Bucket=RTL_S3_BUCKET, Key=key)
                        pkg_content = resp["Body"].read().decode("utf-8", errors="replace")
                    elif "overlay_memory_wrapper" in lower_key and not memory_content:
                        resp = s3_client.get_object(Bucket=RTL_S3_BUCKET, Key=key)
                        memory_content = resp["Body"].read().decode("utf-8", errors="replace")
                    elif "xbar_slave_decode" in lower_key and not xbar_content:
                        resp = s3_client.get_object(Bucket=RTL_S3_BUCKET, Key=key)
                        xbar_content = resp["Body"].read().decode("utf-8", errors="replace")
        except Exception as e:
            logger.warning(json.dumps({
                "event": "overlay_s3_read_error", "error": str(e),
            }))

        cpu_params = extract_cpu_cluster_params(pkg_content) if pkg_content else {}

        # OpenSearch에서 Overlay 모듈 조회
        parsed_docs = _opensearch_scroll_query(pipeline_id, "module_parse")
        overlay_modules = [
            d for d in parsed_docs
            if d.get("module_name", "").lower().startswith("tt_overlay")
            or d.get("module_name", "") in (
                "tt_idma_wrapper", "tt_rocc_accel", "tt_fds_wrapper",
            )
        ]

        roles = identify_submodule_roles(overlay_modules)
        l1_cache = extract_l1_cache_params(memory_content) if memory_content else {}
        apb_slaves = extract_apb_slaves(xbar_content) if xbar_content else []

        doc = {
            "pipeline_id": pipeline_id,
            "analysis_type": "overlay_deep",
            "cpu_cluster": cpu_params,
            "submodule_roles": roles,
            "l1_cache": l1_cache,
            "apb_slaves": apb_slaves,
        }
        _index_document(doc)

        _update_dynamodb_status(pipeline_id, stage, "completed",
                               extra={"overlay_modules": len(overlay_modules)})

        logger.info(json.dumps({
            "event": "overlay_deep_analysis_complete",
            "pipeline_id": pipeline_id,
            "overlay_modules": len(overlay_modules),
            "roles_identified": len(roles),
        }))
        return {"status": "completed", "overlay_modules": len(overlay_modules),
                "roles_identified": len(roles)}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "overlay_deep_analysis_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


# ---------------------------------------------------------------------------
# Task 5.6: Main Dispatcher
# ---------------------------------------------------------------------------
# Task 16.3: SRAM Inventory
# ---------------------------------------------------------------------------

def handle_sram_inventory(event: dict[str, Any]) -> dict[str, Any]:
    """SRAM Inventory 추출 핸들러.

    1. OpenSearch에서 hierarchy 문서 조회
    2. build_sram_inventory() 호출
    3. S3에 JSON 저장 + OpenSearch 인덱싱
    4. DynamoDB 상태 업데이트
    """
    pipeline_id = event["pipeline_id"]
    stage = "sram_inventory"
    _update_dynamodb_status(pipeline_id, stage, "in_progress")

    try:
        hierarchy_docs = _opensearch_scroll_query(pipeline_id, "hierarchy")
        if not hierarchy_docs:
            # hierarchy가 없으면 module_parse에서 직접 추출 시도
            hierarchy_docs = _opensearch_scroll_query(pipeline_id, "module_parse")

        inventory = build_sram_inventory(hierarchy_docs)

        # S3에 JSON 저장
        if RTL_S3_BUCKET:
            s3_key = f"rtl-parsed/sram_inventory/{pipeline_id}/sram_inventory.json"
            s3_client.put_object(
                Bucket=RTL_S3_BUCKET, Key=s3_key,
                Body=json.dumps(inventory, ensure_ascii=False).encode("utf-8"),
                ContentType="application/json",
            )

        # OpenSearch 인덱싱
        doc = {
            "pipeline_id": pipeline_id,
            "analysis_type": "sram_inventory",
            "sram_inventory": inventory.get("memory_instances", []),
            "sram_summary": inventory.get("summary", {}),
        }
        _index_document(doc)

        total = inventory.get("summary", {}).get("total_count", 0)
        _update_dynamodb_status(pipeline_id, stage, "completed",
                               extra={"memory_instances_found": total})

        logger.info(json.dumps({
            "event": "sram_inventory_complete",
            "pipeline_id": pipeline_id,
            "memory_instances_found": total,
        }))
        return {"status": "completed", "memory_instances_found": total}

    except Exception as e:
        _update_dynamodb_status(pipeline_id, stage, "failed",
                               error_message=str(e))
        logger.error(json.dumps({
            "event": "sram_inventory_error",
            "pipeline_id": pipeline_id,
            "error": str(e),
        }))
        raise


# ---------------------------------------------------------------------------

# Stage → handler mapping
_STAGE_HANDLERS = {
    "hierarchy_extraction": handle_hierarchy_extraction,
    "clock_domain_analysis": handle_clock_domain_analysis,
    "dataflow_tracking": handle_dataflow_tracking,
    "topic_classification": handle_topic_classification,
    "claim_generation": handle_claim_generation,
    "hdd_generation": handle_hdd_generation,
    "variant_delta": handle_variant_delta,
    "backfill_pipeline_id": handle_backfill_pipeline_id,
    "clear_index": handle_clear_index,
    "reparse_all": handle_reparse_all,
    "chip_config": handle_chip_config,
    "edc_topology": handle_edc_topology,
    "noc_protocol": handle_noc_protocol,
    "overlay_deep_analysis": handle_overlay_deep_analysis,
    "sram_inventory": handle_sram_inventory,
}


def analysis_handler(event: dict[str, Any], context: Any = None) -> dict[str, Any]:
    """Step Functions에서 호출하는 분석 파이프라인 핸들러.

    event에서 ``stage``와 ``pipeline_id``를 읽어 적절한 분석 함수를 디스패치한다.
    공통 에러 처리로 DynamoDB 상태 업데이트와 CloudWatch 로그 기록을 수행한다.

    Args:
        event: Step Functions에서 전달하는 이벤트.
            필수: ``stage`` (str), ``pipeline_id`` (str)
            선택: ``s3_prefix`` (str)
        context: Lambda context (사용하지 않음).

    Returns:
        분석 결과 dict (stage별 상이).

    Raises:
        ValueError: stage 또는 pipeline_id가 누락된 경우.
    """
    stage = event.get("stage")
    pipeline_id = event.get("pipeline_id")

    if not pipeline_id:
        error_msg = "pipeline_id is required"
        logger.error(json.dumps({"event": "analysis_handler_error", "error": error_msg}))
        raise ValueError(error_msg)

    if not stage:
        error_msg = "stage is required"
        logger.error(json.dumps({
            "event": "analysis_handler_error",
            "pipeline_id": pipeline_id,
            "error": error_msg,
        }))
        raise ValueError(error_msg)

    handler_fn = _STAGE_HANDLERS.get(stage)
    if handler_fn is None:
        error_msg = f"unknown stage: {stage}"
        logger.error(json.dumps({
            "event": "analysis_handler_error",
            "pipeline_id": pipeline_id,
            "error": error_msg,
        }))
        raise ValueError(error_msg)

    logger.info(json.dumps({
        "event": "analysis_handler_start",
        "pipeline_id": pipeline_id,
        "stage": stage,
    }))

    try:
        # context가 필요한 핸들러에 전달 (타임아웃 기반 분할 실행)
        if stage in ("topic_classification",):
            result = handler_fn(event, context=context)
        else:
            result = handler_fn(event)
        logger.info(json.dumps({
            "event": "analysis_handler_complete",
            "pipeline_id": pipeline_id,
            "stage": stage,
            "result": result,
        }))
        return result
    except Exception as e:
        logger.error(json.dumps({
            "event": "analysis_handler_failed",
            "pipeline_id": pipeline_id,
            "stage": stage,
            "error": str(e),
        }))
        raise
